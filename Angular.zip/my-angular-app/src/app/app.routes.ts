import { Routes } from '@angular/router';
import { LoginPage } from './login-page/login-page';
import { CreateNewAcc } from './create-new-acc/create-new-acc';
import { Homepage } from './homepage/homepage';

export const routes: Routes = [
  
];
